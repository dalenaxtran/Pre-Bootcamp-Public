var value = 3;

function incrementbutton() {
    var element = document.getElementById("increment");

    value++;

    element.innerHTML = value;

    console.log(value);
    document.getElementById("increment").innerHTML = value;
}