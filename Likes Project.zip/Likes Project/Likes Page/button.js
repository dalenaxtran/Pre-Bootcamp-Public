var value = 3;

function incrementbutton() {
    var element = document.getElementById("increment");

    value++;

    element.innerHTML = value;

    console.log(value);
    document.getElementById("increment").innerHTML = value;
}

var value = 12;

function incrementbutton1() {
    var element = document.getElementById("increment1");

    value++;

    element.innerHTML = value;

    console.log(value);
    document.getElementById("increment1").innerHTML = value;
}

var value = 9;

function incrementbutton2() {
    var element = document.getElementById("increment2");

    value++;

    element.innerHTML = value;

    console.log(value);
    document.getElementById("increment2").innerHTML = value;
}